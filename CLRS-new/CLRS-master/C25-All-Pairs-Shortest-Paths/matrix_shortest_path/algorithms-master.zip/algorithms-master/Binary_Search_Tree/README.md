# This is a simple implementation of binary search tree.
