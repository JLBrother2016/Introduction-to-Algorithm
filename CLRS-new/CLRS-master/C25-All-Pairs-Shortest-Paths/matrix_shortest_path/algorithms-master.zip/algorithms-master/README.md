## algorithms

All code are written in C.

