# kruskal
Implementation in C++ of the Kruskal algorithm to find a Minimum Spanning Tree using disjoint-set data structures
