# kruskal
Use kruskal algerithm to caculate the Minimum Spanning Tree
