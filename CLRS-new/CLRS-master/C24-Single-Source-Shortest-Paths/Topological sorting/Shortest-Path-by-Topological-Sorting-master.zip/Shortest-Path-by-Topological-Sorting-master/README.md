#Shortest Path by Topological Sorting

##Single-Source Shortest Paths in Directed Acyclic Graphs

Given a Weighted DAG and a source vertext. Find the shortest paths from given source to all other vertices.