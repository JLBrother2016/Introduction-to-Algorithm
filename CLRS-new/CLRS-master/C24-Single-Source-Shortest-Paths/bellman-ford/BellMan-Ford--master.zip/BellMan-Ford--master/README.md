# BellMan-Ford-
 Summary: 
 This program implement BellMan-Ford algorithm as described in the text book in Section 24.1 CLRS.   
 Input from text file is passed as command line agruments.The input-file contain adjacency list, contin Vertex, 
 adjacent edges and weight. An edge will be a tuple consisting of the adjacent vertex and the edge weight. vertices represented by single alphabetic characters.   
 -----> Output:shortest distance from a single a source       
 1.console: Intermidate steps to show implimentation Bellman-Ford algorithm in full and filnal result of the shortest_path 
 will be dispalayed.    
 
 How compile/run prgrm:    
 1. g++ -std=c++11 BellmanFord.cpp  
 2. ./a.out < input.txt
