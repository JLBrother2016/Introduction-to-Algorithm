#include <iostream>
#include <unordered_map>
#include "src/dijkstra_heap.h"

int main()
{
    /* Test heap operations */
    dij::Heap Q;
    Q.push(2, 1.4);
    Q.push(1, 1.5);
    Q.push(3, 1.3);
    Q.push(5, 1.1);
    Q.push(4, 1.2);

    Q.update_dist(3, 0.9);

    std::cout << Q.empty() << std::endl;

    int max = Q.size();
    for (int i = 0; i < max; ++i)
    {
        std::pair<int, double> u = Q.pop();
        std::cout << "id: " << u.first
            << " dist: " << u.second << std::endl;
    }

    std::cout << Q.empty() << std::endl;

    dij::Graph world;

    world.connect(1, 2, 10);
    world.connect(1, 4, 5);
    world.connect(1, 5, 7);
    world.connect(2, 3, 1);
    world.connect(2, 4, 2);
    world.connect(3, 4, 9);
    world.connect(3, 5, 4);
    world.connect(4, 5, 2);

    std::unordered_map<int, double> dist;
    std::unordered_map<int, int>    prev;

    dij::Dijkstra(world, 1, &dist, &prev);

    for (auto d : dist)
        std::cout << d.first << " " << d.second << std::endl;

}

