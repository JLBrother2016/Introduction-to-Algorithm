#include <unordered_map>
#include <vector>
#include <algorithm>
#include "dijkstra_heap.h"

struct minDist {
    bool operator() (const std::pair<int, double> a,
       const std::pair<int, double> b)
    {
        return a.second > b.second;
    }
};

void dij::Heap::push(int destination, double distance)
{
    _values.push_back(std::make_pair(destination, distance));
    std::push_heap(_values.begin(), _values.end(),
            minDist());
}

std::pair<int, double> dij::Heap::pop()
{
    std::pair<int, double> min = _values.front();
    std::pop_heap(_values.begin(), _values.end(),
            minDist());
    _values.pop_back();
    return min;
}

void dij::Heap::update_dist(int destination, double alt)
{
    for (auto&& p : _values)
        if (p.first == destination)
        {
            p.second = alt;
            break;
        }
    std::make_heap(_values.begin(), _values.end(), minDist());
}

int dij::Heap::size()
{
    return _values.size();
}

bool dij::Heap::empty()
{
    return (_values.size() == 0);
}

void dij::Graph::connect(int origin, int destination, double distance)
{
    _neighbors[origin][destination] = distance;
    _neighbors[destination][origin] = distance;
}

std::vector<int> dij::Graph::neighbors(int node)
{
    std::vector<int> neighbors;
    for (auto n : _neighbors[node])
        neighbors.push_back(n.first);
    return neighbors;
}

std::vector<int> dij::Graph::nodes()
{
    std::vector<int> nodes;
    for (auto n : _neighbors)
        nodes.push_back(n.first);
    return nodes;
}

void dij::Graph::load(std::vector<Edge> edges)
{
    for (Edge edge : edges)
        this->connect(edge.origin, edge.destination, edge.distance);
}

double dij::Graph::getDistance(int origin, int destination)
{
   return _neighbors[origin][destination];
}


/* Implementation based off the pseudocode in Wikipedia */
void dij::Dijkstra(Graph graph, int origin,
        std::unordered_map<int, double> *dist, std::unordered_map<int, int> *prev)
{
    (*dist)[origin] = 0;

    dij::Heap Q;

    double alt;

    for (int n : graph.nodes())
    {
        if (n != origin)
        {
            (*dist)[n] = dij::INF;
            (*prev)[n] = -1;
        }
        Q.push(n, (*dist)[n]);
    }

    while (!Q.empty())
    {
        /* Get node with min dist */
        std::pair<int, double> u = Q.pop();

        for (auto n : graph.neighbors(u.first))
        {
            alt = (*dist)[u.first] + graph.getDistance(u.first, n);
            if (alt < (*dist)[n])
            {
                (*dist)[n] = alt;
                (*prev)[n] = u.first;
                Q.update_dist(n, alt);
            }
        }
    }
}

