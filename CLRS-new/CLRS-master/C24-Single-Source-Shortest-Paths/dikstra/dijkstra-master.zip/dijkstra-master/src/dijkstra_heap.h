/* Copyright James Pan
 * Jan 2017 */
#ifndef DIJKSTRA_H_
#define DIJKSTRA_H_

#include <unordered_map>
#include <vector>
#include <limits>

namespace dij {

const float INF = std::numeric_limits<float>::infinity();

class Heap
{
    std::vector<std::pair<int, double>> _values;

    public:

        /* Add value to the heap */
        void push(int destination, double distance);

        /* Remove and return min value */
        std::pair<int, double> pop();

        /* Update priority */
        void update_dist(int destination, double alt);

        /* Return size */
        int size();

       /* Return true if empty */
        bool empty();
};

class Edge
{
    public:
        int origin;
        int destination;
        double distance;
};

class Graph
{
    /* Structure of _neighbors:
     *
     * _neighbors[origin] = {
     *     destination1: distance1
     *     destination2: distance2
     *     ...
     * } */
    std::unordered_map<int, std::unordered_map<int, double>> _neighbors;

    public:

        /* Connect an origin to its destination and vice versa
         * (undirected, so we form two edges) */
        void connect(int origin, int destination, double distance);

        /* Return neighbors of node */
        std::vector<int> neighbors(int node);

        /* Return all nodes in the graph */
        std::vector<int> nodes();

        /* Load edges into the graph */
        void load(std::vector<Edge> edges);

        /* Return distance */
        double getDistance(int origin, int destination);
};

void Dijkstra(Graph graph, int origin,
        std::unordered_map<int, double> *dist, std::unordered_map<int, int> *prev);

} // namespace dij

#endif

