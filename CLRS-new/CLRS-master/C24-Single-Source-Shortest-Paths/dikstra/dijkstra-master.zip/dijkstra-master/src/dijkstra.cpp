#include <unordered_map>
#include <vector>
#include <algorithm>
#include "dijkstra.h"

void dij::Graph::connect(int origin, int destination, double distance)
{
    _neighbors[origin][destination] = distance;
    _neighbors[destination][origin] = distance;
}

std::vector<int> dij::Graph::neighbors(int node)
{
    std::vector<int> neighbors;
    for (auto n : _neighbors[node])
        neighbors.push_back(n.first);
    return neighbors;
}

std::vector<int> dij::Graph::nodes()
{
    std::vector<int> nodes;
    for (auto n : _neighbors)
        nodes.push_back(n.first);
    return nodes;
}

void dij::Graph::load(std::vector<Edge> edges)
{
    for (Edge edge : edges)
        this->connect(edge.origin, edge.destination, edge.distance);
}

double dij::Graph::getDistance(int origin, int destination)
{
   return _neighbors[origin][destination];
}


/* Implementation based off the pseudocode in Wikipedia */
void dij::Dijkstra(Graph graph, int origin,
        std::unordered_map<int, double> *dist, std::unordered_map<int, int> *prev)
{
    std::vector<int>    Q;
    double              alt;

    for (int n : graph.nodes())
    {
        (*dist)[n] = dij::INF;
        (*prev)[n] = -1;
        Q.push_back(n);
    }

    (*dist)[origin] = 0;

    while (!Q.empty())
    {
        /* Get node with min dist */
        int u;
        double min_dist = dij::INF;
        for (auto n : Q)
            if ((*dist)[n] < min_dist)
            {
                min_dist = (*dist)[n];
                u = n;
            }

        Q.erase(remove(Q.begin(), Q.end(), u), Q.end());

        for (int v : graph.neighbors(u))
        {
            alt = (*dist)[u] + graph.getDistance(u, v);
            if (alt < (*dist)[v])
            {
                (*dist)[v] = alt;
                (*prev)[u] = v;
            }
        }
    }
}

