Dijkstra's algorithm
====================
There are two implementations, naive Dijkstra (dijkstra.h)
and heap-based (dijkstra_heap.h).

Graph should be represented as edges in the format

``from to distance``

The example in test.cpp uses the heap-based implementation.

To try it out,

```
> g++ -std=c++11 test.cpp src/dijkstra_heap.cpp -o test
> ./test
```

This generates the following output:

```
5 7
3 8
1 0
2 7
4 5
```

where the first column is the destination node and the second column is the
distance to it.
