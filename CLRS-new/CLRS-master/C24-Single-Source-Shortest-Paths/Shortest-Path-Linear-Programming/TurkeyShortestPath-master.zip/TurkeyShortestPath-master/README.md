# TurkeyShortestPath
Linear Programming model to find the shortest paths between İstanbul and every other city.

Türkiye şehirler arası en kısa mesafeyi hesaplayan lineer programlama modeli. Xpress IVE kullanılarak yazılmıştır. Mosel dili kullanılmıştır. İstanbul ile diğer şehirler arasındaki mesafe komşu iller arasındaki mesafe kullanılarak hesaplanmıştır. Komşu iller haritasında şehirler arasındaki mesafeleri ve de Türkiye haritasının graph halini bulabilirsiniz.
